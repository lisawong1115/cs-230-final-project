/** 
* CatifyGUI.java
* 
* @author Lisa Huang (rhuang2), Huihan Li (hli3) and Tina Zhang (yzhang16)
* @since 12-08-2017
*/
import javax.swing.*;
import java.awt.*;

public class CatifyGUI {

  public static void main (String[] args) {
    JFrame frame = new JFrame("CatifyGUI");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    frame.setPreferredSize(new Dimension(800,600));
    frame.setMaximumSize(new Dimension(800,600));
    frame.setMinimumSize(new Dimension(800,600));
    
    JPanel cardHolder = new JPanel();
    cardHolder.setLayout(new CardLayout());
    //CardLayout cards = new CardLayout();

    MainPanel mainP = new MainPanel(cardHolder);
    SettingPanel settingP = new SettingPanel(cardHolder);
    GamePanel gameP = new GamePanel(cardHolder);
    ResultPanel resultP = new ResultPanel(cardHolder);
    HelpPanel helpP = new HelpPanel(cardHolder);

    //cardHolder.setLayout(new CardLayout());
    
    cardHolder.add(mainP, "Main Panel");
    cardHolder.add(settingP, "Setting Panel");
    cardHolder.add(gameP, "Game Panel");
    cardHolder.add(resultP, "Result Panel");
    cardHolder.add(helpP, "Help Panel");
    //cardHolder.add(mainP, "Main Panel");

    frame.getContentPane().add(cardHolder);

    //Create tab panels
    /*JTabbedPane tp = new JTabbedPane();
    tp.addTab("Main", new MainPanel());
    tp.addTab("Setting", new SettingPanel());
    tp.addTab("Game", new GamePanel());
    tp.addTab("Result", new ResultPanel());*/
    
    
    
    //adds the whole panel to the frame
    //frame.getContentPane().add(tp);
    
    frame.pack();
    frame.setVisible(true);
  }
}